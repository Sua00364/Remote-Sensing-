# ENMPG03 - R Assignment 1: Ragweed growth analysis

# dplyr library package offers tools for grouping, filtering, joining along with summarising data
library(dplyr)

# tidyr library package offers tools to reshape plant-height measurements to a tidy frame
library(tidyr)

# ggplot2 library package offers tools to create the exploratory plots 
library(ggplot2)

# Save the created tables and plots into a separate results folder called "ragweed_results"
results_folder <- "ragweed_results"
dir.create(results_folder, showWarnings = FALSE, recursive = TRUE)

# Console dividers used to separate the generated output for ecery single assigned task
banner <- function(label) {
  cat("\n", strrep("-", 72), "\n", label, "\n", strrep("-", 72), "\n", sep = "")
}

needed_files <- c("ragweed_site_data.csv", "ragweed_height_data.csv")
absent_files <- needed_files[!file.exists(needed_files)]
if (length(absent_files) > 0) {
  stop("Cannot find: ", paste(absent_files, collapse = ", "),
       ". Set the working directory to the folder holding the data.")
}


# =============================================================================
# TASK 1 | Data import and assembly
# =============================================================================
banner("TASK 1: import and assemble")

#The site data set is clean with each row representing one site and one variable per column
# The Height Data Set contains ten heights in different columns
field_sites       <- read.csv("ragweed_site_data.csv",   stringsAsFactors = FALSE)
stem_heights_wide <- read.csv("ragweed_height_data.csv", stringsAsFactors = FALSE)

str(field_sites)
str(stem_heights_wide)


# Individual plant heights are converted to a single column prior to aggregation
stem_heights_long <- stem_heights_wide |>
  pivot_longer(cols      = starts_with("ragweed_number_"),
               names_to  = "plant_label",
               values_to = "height_cm")

height_by_site <- stem_heights_long |>
  group_by(site_number) |>
  summarise(mean_height = mean(height_cm),
            n_plants    = n(),
            .groups     = "drop")

# Validation checks ensure that there are ten plants at each site and matching site numbers
stopifnot(!anyDuplicated(field_sites$site_ID),
          all(height_by_site$n_plants == 10),
          setequal(field_sites$site_ID, height_by_site$site_number))


# Combining site attributes and mean plant height using site number joining
survey_assembled <- field_sites |>
  rename(site_number = site_ID) |>
  left_join(select(height_by_site, site_number, mean_height),
            by = "site_number") |>
  relocate(site_number, mean_height)

cat("Sites assembled:", nrow(survey_assembled), "\n")
print(head(survey_assembled))
write.csv(survey_assembled, file.path(results_folder, "task1_assembled_sites.csv"),
          row.names = FALSE)


# =============================================================================
# TASK 2 | Data inspection and cleaning
# =============================================================================
banner("TASK 2: data cleaning")

# First summary output shows variable range, missing values, categories
summary(survey_assembled)
table(survey_assembled$land_use, useNA = "ifany")
table(survey_assembled$beetles,  useNA = "ifany")

# Box plots identify outliers without considering them as mistakes by default
data_audit_plot <- survey_assembled |>
  pivot_longer(c(mean_height, soil_pH, soil_N, soil_moisture,
                 rainfall, temperature, wind_speed),
               names_to = "measure", values_to = "reading") |>
  ggplot(aes(x = "", y = reading)) +
  geom_boxplot(outlier.colour = "red") +
  facet_wrap(~ measure, scales = "free_y", nrow = 2) +
  labs(x = NULL, y = "Recorded value", title = "Task 2: first look at the numbers")
print(data_audit_plot)
ggsave(file.path(results_folder, "task2_initial_data_audit.png"),
       data_audit_plot, width = 12, height = 7, dpi = 300)

# Sorted nitrogen levels show repeating data at the two ends
nitrogen_audit_plot <- ggplot(survey_assembled,
                            aes(x = rank(soil_N, ties.method = "first"), y = soil_N)) +
  geom_point() +
  labs(x = "Rank of site by soil N", y = "Soil N (mg/kg)",
       title = "Task 2: soil N ranked - flat ends are suspicious")
print(nitrogen_audit_plot)
ggsave(file.path(results_folder, "task2_ranked_nitrogen.png"),
       nitrogen_audit_plot, width = 7, height = 5, dpi = 300)

# Soil nitrogen extreme values involve repeated values close to 150 and 7022 mg/kg
# Repeated nitrogen values should be flagged NA and not have estimated corrections applied
# Negative rainfall values are invalid and missing wind values are flagged NA
repeated_n_value <- duplicated(survey_assembled$soil_N) |
  duplicated(survey_assembled$soil_N, fromLast = TRUE)
impossible_rain  <- !is.na(survey_assembled$rainfall) & survey_assembled$rainfall < 0

cat("Sites with a repeated soil N value:",
    survey_assembled$site_number[repeated_n_value], "\n")
cat("Sites with negative rainfall:",
    survey_assembled$site_number[impossible_rain], "\n")
cat("Sites with missing wind speed:",
    survey_assembled$site_number[is.na(survey_assembled$wind_speed)], "\n")

# Numerical records that are incomplete are omitted from the modelling dataset
survey_tidied <- survey_assembled |>
  mutate(
    land_use = factor(tolower(trimws(land_use)),
                      levels = c("no management", "grazed", "mown")),
    beetles  = tolower(trimws(beetles)),
    beetles  = factor(if_else(beetles == "true", "present", beetles),
                      levels = c("absent", "present")),
    soil_N   = if_else(repeated_n_value, NA_real_, soil_N),
    rainfall = if_else(impossible_rain,  NA_real_, rainfall)
  )

# Category validation identifies any labels missed during standardisation.
stopifnot(!anyNA(survey_tidied$land_use), !anyNA(survey_tidied$beetles))
cat("\nMissing values left after cleaning:\n")
print(colSums(is.na(survey_tidied)))

# Save the cleaned data and a record of the issues identified in each site.
write.csv(survey_tidied, file.path(results_folder, "task2_cleaned_sites.csv"),
          row.names = FALSE)
quality_flags <- data.frame(
  site_number = survey_assembled$site_number,
  repeated_nitrogen = repeated_n_value,
  negative_rainfall = impossible_rain,
  missing_wind_speed = is.na(survey_assembled$wind_speed)
)
write.csv(quality_flags, file.path(results_folder, "task2_quality_flags.csv"),
          row.names = FALSE)


# =============================================================================
# TASK 3 | Exploratory data analysis
# =============================================================================
banner("TASK 3: exploration")

# Group summaries include site counts, medians, maxima and standard deviations.
height_summary <- survey_tidied |>
  group_by(land_use, beetles) |>
  summarise(n_sites   = n(),
            median_cm = median(mean_height),
            max_cm    = max(mean_height),
            sd_cm     = sd(mean_height),
            .groups   = "drop")
print(height_summary)
write.csv(height_summary, file.path(results_folder, "task3_group_summary.csv"),
          row.names = FALSE)

# Mown sites show the lowest plant heights, followed by grazed sites.
# Within unmanaged sites, beetle presence is associated with shorter ragweed.
land_use_plot <- ggplot(survey_tidied,
                        aes(x = land_use, y = mean_height, fill = beetles)) +
  geom_boxplot(alpha = 0.6, outlier.shape = NA) +
  geom_point(position = position_jitterdodge(jitter.width = 0.15), alpha = 0.6) +
  labs(x = "Land use", y = "Mean height per site (cm)", fill = "Beetles",
       title = "Task 3b(i): height by land use and beetles")
print(land_use_plot)
ggsave(file.path(results_folder, "task3_land_use_beetles.png"),
       land_use_plot, width = 8, height = 5, dpi = 300)

# Unmanaged sites show a positive nitrogen-height trend with considerable scatter.
# The small mown sample limits interpretation of the fitted trend.
nitrogen_height_plot <- survey_tidied |>
  filter(!is.na(soil_N)) |>
  ggplot(aes(x = soil_N, y = mean_height, colour = land_use)) +
  geom_point(alpha = 0.7) +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE) +
  labs(x = "Soil N (mg/kg)", y = "Mean height per site (cm)", colour = "Land use",
       title = "Task 3b(ii): height against soil nitrogen")
print(nitrogen_height_plot)
ggsave(file.path(results_folder, "task3_nitrogen_land_use.png"),
       nitrogen_height_plot, width = 8, height = 5, dpi = 300)

# =============================================================================
# TASK 4 | Modelling dataset preparation
# =============================================================================
banner("TASK 4: subset for modelling")

# Mown, grazed and beetle-affected sites are removed before environmental modelling.
# Site number identifies observations and is excluded from the predictor set.
predictor_names <- c("soil_pH", "soil_N", "soil_moisture",
                     "rainfall", "temperature", "wind_speed")


# Complete-case filtering maintains a consistent sample across model comparisons.
survey_for_model <- survey_tidied |>
  filter(land_use == "no management", beetles == "absent") |>
  drop_na(all_of(predictor_names))

cat("Sites available for modelling:", nrow(survey_for_model), "\n")
write.csv(survey_for_model, file.path(results_folder, "task4_modelling_sites.csv"),
          row.names = FALSE)

if (file.exists("ragweed_data_at_end_of_task_4.csv")) {
  course_check <- read.csv("ragweed_data_at_end_of_task_4.csv")
  cat("Same sites as the course checkpoint:",
      setequal(survey_for_model$site_number, course_check$site_number), "\n")
}


# =============================================================================
# TASK 5 | Minimum adequate model for mean height
# =============================================================================
banner("TASK 5: modelling")


# Correlations and variance inflation factors assess predictor collinearity.
print(round(cor(survey_for_model[predictor_names]), 2))

variance_inflation <- function(data, terms) {
  vapply(terms, function(focus) {
    others <- setdiff(terms, focus)
    if (length(others) == 0) return(1)
    r_sq <- summary(lm(reformulate(others, focus), data = data))$r.squared
    1 / (1 - r_sq)
  }, numeric(1))
}
cat("\nVariance inflation factors, full model:\n")
print(round(variance_inflation(survey_for_model, predictor_names), 1))

# The initial multiple regression includes all six environmental predictors.
full_fit <- lm(reformulate(predictor_names, "mean_height"), data = survey_for_model)
print(summary(full_fit))

# Backward selection removes the least significant predictor using partial F-tests.
# A fixed sample permits valid comparisons between nested candidate models.
terms_left      <- predictor_names
elimination_log <- data.frame(step = integer(), dropped = character(),
                              p_value = numeric())
repeat {
  trial_fit <- lm(reformulate(terms_left, "mean_height"), data = survey_for_model)
  f_tests   <- drop1(trial_fit, test = "F")
  term_p    <- setNames(f_tests[["Pr(>F)"]][-1], rownames(f_tests)[-1])
  if (max(term_p) < 0.05) break
  weakest <- names(which.max(term_p))
  elimination_log <- rbind(elimination_log,
                           data.frame(step = nrow(elimination_log) + 1,
                                      dropped = weakest,
                                      p_value = round(term_p[[weakest]], 3)))
  terms_left <- setdiff(terms_left, weakest)
}

# The selected minimum adequate model retains moisture, nitrogen and temperature.
adequate_fit <- trial_fit
cat("\nTerms removed, in order:\n")
print(elimination_log)
write.csv(elimination_log, file.path(results_folder, "task5_model_reduction.csv"),
          row.names = FALSE)
print(summary(adequate_fit))
print(round(confint(adequate_fit), 3))

print(anova(adequate_fit, full_fit))

# Residual plots assess linearity, constant variance, distribution shape and influence.
# Lower-tail Q-Q departures and increasing residual spread indicate assumption concerns.
old_par <- par(mfrow = c(2, 2))
plot(adequate_fit, which = 1:4)
par(old_par)

# Save a high-resolution copy of the four diagnostic panels.
png(file.path(results_folder, "task5_model_diagnostics.png"),
    width = 2400, height = 1800, res = 240)
par(mfrow = c(2, 2))
plot(adequate_fit, which = 1:4)
dev.off()

# The Shapiro-Wilk result (p < 0.001) indicates departure from residual normality.
print(shapiro.test(residuals(adequate_fit)))


# An auxiliary regression provides a Breusch-Pagan-style variance test.
# The resulting p-value (< 0.001) suggests non-constant residual variance.
aux_fit  <- lm(reformulate(terms_left, "sq_resid"),
               data = transform(survey_for_model[terms_left],
                                sq_resid = residuals(adequate_fit)^2))
lm_stat  <- nrow(survey_for_model) * summary(aux_fit)$r.squared
cat("Breusch-Pagan LM =", round(lm_stat, 2), " p =",
    signif(pchisq(lm_stat, df = length(terms_left), lower.tail = FALSE), 3), "\n")

# Cook's distance flags potentially influential sites without automatic deletion.
# Diagnostic violations warrant caution when interpreting p-values and confidence intervals.
cooks_values <- cooks.distance(adequate_fit)
cat("Sites with Cook's distance > 4/n:",
    sum(cooks_values > 4 / nrow(survey_for_model)),
    "| largest value:", round(max(cooks_values), 2), "\n")

# Save the main model results for later reporting.
model_notes <- c(
  "Full model:", capture.output(summary(full_fit)),
  "", "Minimum adequate model:", capture.output(summary(adequate_fit)),
  "", "Coefficient confidence intervals:", capture.output(confint(adequate_fit)),
  "", "Shapiro-Wilk test:", capture.output(shapiro.test(residuals(adequate_fit))),
  "", paste("Variance test: LM =", round(lm_stat, 2),
            "; p =", signif(pchisq(lm_stat, df = length(terms_left),
                                    lower.tail = FALSE), 3))
)
writeLines(model_notes, file.path(results_folder, "task5_model_summary.txt"))

# =============================================================================
# TASK 6 | Effect sizes, marginal plots and management implications
# =============================================================================
banner("TASK 6: interpretation")


# Standardised predictors allow effect magnitudes to be compared across units.
# The response remains in centimetres, giving effects in cm per standard deviation.
standardised_data <- survey_for_model |>
  mutate(across(all_of(terms_left), \(v) as.numeric(scale(v))))
standardised_fit  <- lm(reformulate(terms_left, "mean_height"), data = standardised_data)

effect_ranking <- data.frame(predictor = terms_left,
                             cm_per_sd = unname(coef(standardised_fit)[terms_left])) |>
  arrange(desc(abs(cm_per_sd)))
print(effect_ranking)
write.csv(effect_ranking, file.path(results_folder, "task6_standardised_effects.csv"),
          row.names = FALSE)

top_two <- effect_ranking$predictor[1:2]

axis_titles <- c(soil_pH = "Soil pH", soil_N = "Soil nitrogen (mg/kg)",
                 soil_moisture = "Soil moisture (% VWC)",
                 rainfall = "Mean annual rainfall (mm)",
                 temperature = "Summer mean temperature (\u00B0C)",
                 wind_speed = "Mean wind speed (m/s)")


# Each marginal effect varies one predictor while fixing remaining predictors at medians.
# Shaded bands represent model-based 95% confidence intervals for mean predictions.
marginal_layers <- function(focal, panel_tag) {
  others    <- setdiff(terms_left, focal)
  baseline  <- as.data.frame(survey_for_model |>
                               summarise(across(all_of(others), median)))
  panel_txt <- paste0("(", panel_tag, ") ", axis_titles[[focal]])
  
  grid_x    <- seq(min(survey_for_model[[focal]]), max(survey_for_model[[focal]]),
                   length.out = 100)
  line_grid <- baseline[rep(1, 100), , drop = FALSE]
  line_grid[[focal]] <- grid_x
  line_df <- data.frame(x = grid_x,
                        predict(adequate_fit, line_grid, interval = "confidence"),
                        panel = panel_txt)
  
  dot_grid <- baseline[rep(1, nrow(survey_for_model)), , drop = FALSE]
  dot_grid[[focal]] <- survey_for_model[[focal]]
  dot_df <- data.frame(x = survey_for_model[[focal]],
                       y = predict(adequate_fit, dot_grid) + residuals(adequate_fit),
                       panel = panel_txt)
  list(lines = line_df, dots = dot_df)
}

layers    <- Map(marginal_layers, top_two, c("a", "b"))
line_data <- bind_rows(lapply(layers, `[[`, "lines")) |>
  mutate(panel = factor(panel, levels = unique(panel)))
dot_data  <- bind_rows(lapply(layers, `[[`, "dots"))  |>
  mutate(panel = factor(panel, levels = unique(panel)))

effects_figure <- ggplot() +
  geom_point(data = dot_data, aes(x, y), colour = "grey50", alpha = 0.55, size = 1.6) +
  geom_ribbon(data = line_data, aes(x, ymin = lwr, ymax = upr),
              fill = "#2A9D8F", alpha = 0.3) +
  geom_line(data = line_data, aes(x, fit), colour = "#1D6F66", linewidth = 1) +
  facet_wrap(~ panel, scales = "free_x", strip.position = "bottom") +
  labs(x = NULL, y = "Mean ragweed height (cm)") +
  theme_classic(base_size = 12) +
  theme(strip.placement  = "outside",      # Facet labels also identify the horizontal axes
        strip.background = element_blank(),
        plot.margin      = margin(8, 14, 8, 8),
        panel.spacing    = unit(1.2, "lines"),
        strip.text       = element_text(size = 11))

print(effects_figure)
ggsave(file.path(results_folder, "task6_marginal_effect_panels.png"),
       effects_figure, width = 8, height = 4, dpi = 300)


# Conservation management interpretation (Task 6)
# (a) At unmanaged, beetle-free sites, greater ragweed height is associated with
#     wetter soil, higher soil nitrogen and warmer summers. Soil moisture shows
#     the strongest standardised association, followed by soil nitrogen.
# (b) Wet, nitrogen-rich sites may warrant closer monitoring because greater
#     plant heights occur under associated conditions. Mown and grazed sites
#     show shorter plants, although observational patterns cannot prove treatment effects.
# (c) The observational design prevents causal conclusions about growth drivers.
#     Non-normal residuals and unequal variance affect conventional model inference
#     and reduce confidence in standard model-based intervals.

banner(paste("Finished: all files saved in", normalizePath(results_folder)))
